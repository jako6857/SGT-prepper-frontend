import { getList } from "../models/categoryModel.js";
import { ProductListView } from "../views/organisms/productViews.js";
import { Layout } from "./layoutController.js";


export const productPage = async () => {
    const { category ='vand-og-vandrensning' } = Object.fromEntries(new URLSearchParams(location.search));
    const data = await getList(category)
    const html = ProductListView(data)
    const layout = Layout("Produkter", html)
    return layout
}