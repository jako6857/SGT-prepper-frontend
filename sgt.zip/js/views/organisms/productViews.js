import { Div, Fragment, Heading, Image, Input, Form, Button, Paragraph, Link } from "../atoms/index.js";
import { addToCart } from "../../models/cartModel.js";
import { price2Dkk } from "../../utils/index.js";
import { isLoggedIn } from "../../services/auth.js";

export const ProductListView = (products, category) => {
    const element = Fragment()

    products.forEach(product => {
        const card = Div('block hover:shadow-lg transition-shadow duration-300 p-4 bg-white rounded-lg border')

        // Product link and content
        const productLink = Link(`?category=${category}&product=${product.slug}`, '', 'block')
        const contentDiv = Div('flex justify-between items-start gap-6')
        const img = Image(
            product.imageUrl ? `http://localhost:4000${product.imageUrl}` : '', 
            product.name, 
            'max-w-[200px] rounded-lg object-cover shadow-md'
        )
        contentDiv.append(img)

        const info = Div('flex-1')
        const h2 = Heading(product.name, 2, 'text-xl font-semibold text-gray-800 mb-2')
        const p = Paragraph('text-gray-600 line-clamp-2')
        p.innerHTML = product.teaser || ''
        info.append(h2, p)

        const cost = Div('text-right space-y-2 min-w-[120px]')
        const priceText = Div('text-lg font-bold text-gray-900')
        priceText.innerText = price2Dkk(product.price)
        cost.append(priceText)

        contentDiv.append(info, cost)
        productLink.append(contentDiv)
        card.append(productLink)

        // Add to cart form
        const form = Form('POST')
        form.className = 'mt-4 flex items-center justify-end gap-2'

        const productIdInput = document.createElement('input')
        productIdInput.type = 'hidden'
        productIdInput.name = 'productId'
        productIdInput.value = product.id // Ensure this is set
        
        const quantity = Input('quantity', 'Antal', 'number', '1', 'w-20 rounded border-gray-300')
        quantity.min = '1'

        const button = Button(
            'Tilføj til kurv', 
            'submit',
            'bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700'
        )

        form.append(productIdInput, quantity, button)
        
        // Prevent form from submitting to URL
        form.addEventListener('submit', async (e) => {
            e.preventDefault()
            const formData = new FormData(e.target)
            
            try {
                await addToCart({
                    productId: parseInt(formData.get('productId')),
                    quantity: parseInt(formData.get('quantity'))
                })
                alert('Produkt tilføjet til kurv!')
            } catch (error) {
                console.error('Add to cart error:', error)
                alert('Kunne ikke tilføje til kurv')
            }
        })

        card.append(form)
        element.append(card)
    })

    return element
}

export const ProductsDetailsView = (product) => {
    const { id, name, imageUrl, description, price } = product
    const element = Div('flex flex-col md:flex-row gap-8 p-6 border rounded-xl bg-white shadow-sm max-w-6xl mx-auto')

    const imageCol = Div('md:w-[400px] shrink-0')
    const img = Image(`http://localhost:4000${imageUrl}`, name, 'w-full rounded-lg shadow-lg object-cover')
    imageCol.append(img)

    const infoCol = Div('flex-1')
    const h3 = Heading(name, 1, 'text-2xl font-bold text-gray-900')
    const p = Paragraph('text-gray-600')
    p.innerHTML = description
    infoCol.append(h3, p)

    // Add to cart form
    const form = Form('POST')
    form.className = 'mt-6'
    
    const productIdInput = document.createElement('input')
    productIdInput.type = 'hidden'
    productIdInput.name = 'productId'
    productIdInput.value = id
    
    const quantity = Input('quantity', 'Antal', 'number', '1', 'w-24 rounded border-gray-300')
    quantity.min = '1'
    
    const button = Button(
        'Tilføj til kurv',
        'submit',
        'mt-4 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700'
    )

    form.append(productIdInput, quantity, button)
    
    form.addEventListener('submit', async (e) => {
        e.preventDefault()
        const formData = new FormData(e.target)
        
        try {
            await addToCart({
                productId: parseInt(formData.get('productId')),
                quantity: parseInt(formData.get('quantity'))
            })
            alert('Produkt tilføjet til kurv!')
        } catch (error) {
            console.error('Add to cart error:', error)
            alert('Kunne ikke tilføje til kurv')
        }
    })

    element.append(form)
    return element
}

